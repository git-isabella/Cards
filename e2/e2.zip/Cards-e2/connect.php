<?php
function connect_db() {
 $servername = "localhost";
 // EDIT HERE YOUR USERNAME AND PASSWORD
 $username = "a1800565";
<<<<<<< HEAD
 $password = "saPA4G62s";
=======
 $password = "password";
>>>>>>> feature/login
 $dbname = "a1800565";
 // Create connection
 $conn = new mysqli($servername, $username, $password, $dbname);
 // Check connection
 if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
 } else {
 }
 return $conn;
}
?>

